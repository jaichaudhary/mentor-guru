import React from 'react'
import './PrelimsKaushal.css'

const PrelimsKaushal = () => {
  return (
    <div className='heading'>This page us not available right now!</div>
  )
}

export default PrelimsKaushal